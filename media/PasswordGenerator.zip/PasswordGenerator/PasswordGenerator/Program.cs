﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

namespace PasswordGenerator
{
    class Program
    {
        static void Main(string[] args) 
        {
            Console.WriteLine("Welcome to password generator. What would you like to do today?\n");
            argumentReader();

        }
        static int numChecker(string input)
        {
            int option;
            bool correctInput = false;
            if(int.TryParse(input,out option))
            {
                correctInput = true;
            }
            else
            {
                while(!correctInput) 
                {
                    Console.WriteLine("Please enter a NUMBER");
                    input = Console.ReadLine();
                    if (int.TryParse(input, out option))
                    {
                        correctInput = true;
                    }
                }
            }
            return option;
        }
        static char charChecker(string input)
        {
            char option;
            bool correctInput = false;
            if (char.TryParse(input, out option))
            {
                correctInput = true;
            }
            else
            {
                while (!correctInput)
                {
                    Console.WriteLine("Please enter a valid CHARACTER");
                    input = Console.ReadLine();
                    if (char.TryParse(input, out option))
                    {
                        correctInput = true;
                    }
                }
            }
            return option;
        }

        static void argumentReader()
        {
            
            Console.WriteLine("Please choose an option (Write JUST  the number of the option)");
            Console.WriteLine("1. Random Password Generator");
            Console.WriteLine("2. Password Improver");
            string input = Console.ReadLine();
            int option = numChecker(input);
            while (option < 0 || option > 2)
            {
                Console.WriteLine("Enter a number from the given RANGE");
                input = Console.ReadLine();
                option = numChecker(input);
            }
            if (option == 1)
            {
                Console.Clear();
                RandomPassword();
                Console.ReadLine();
            }
            else if (option == 2) 
            {
                Console.Clear();
                wordToPassword();
            }

        }
        static void backMainMenu()
        {
            Console.WriteLine("Would you like to go back to the main menu Y/N?");
            string input = Console.ReadLine();
            char answer = charChecker(input);
            while(answer != 'y' && answer != 'n' && answer != 'Y' && answer != 'N')
            {
                Console.WriteLine("Would you like to go back to the main menu Y/N?(TYPE A VALID CHARACTER)");
                input = Console.ReadLine();
                answer = charChecker(input);
            }
            if(answer == 'y' || answer == 'Y')
            {
                Console.Clear();
                argumentReader();
            }
            else
            {
                Console.Clear();
                Console.WriteLine("See you soon ;)");
            }
        }
        static bool isVowel(char ch) 
        {
            if (char.IsUpper(ch))
            {
                ch = char.ToLower(ch);

            }
            if(ch ==  'a' || ch == 'e' || ch == 'o' || ch == 'i'|| ch == 'u') 
            {
                return true;
            }
            return false;
        }
        static char vowelToNumber(char ch)
        {
            if (char.IsUpper(ch))
            {
                ch = char.ToLower(ch);

            }
            switch (ch) 
            {
                case 'a':
                    Random randomA = new Random();
                    int aRan = randomA.Next(2);
                    switch (aRan)
                    {
                        case 0:
                            return '@';
                        case 1:
                            return '4';
                        default:
                            return 'A';
                    }
                case 'e':
                    return '3';
                case 'o':
                    Random randomO = new Random();
                    int oRan = randomO.Next(2);
                    switch (oRan)
                    {
                        case 0:
                            return '*';
                        case 1:
                            return '0';
                        case 2:
                            return '.';
                        default:
                            return 'O';
                    }
                case 'i':
                    Random randomI = new Random();
                    int iRan = randomI.Next(2);
                    switch (iRan)
                    {
                        case 0:
                            return '1';
                        case 1:
                            return '/';
                        default:
                            return 'I';
                    }
                case 'u':
                    Random randomU = new Random();
                    int uRan = randomU.Next(2);
                    switch (uRan)
                    {
                        case 0:
                            return 'v';
                        case 1:
                            return 'V';
                        default:
                            return 'U';
                    }
                default:
                    return '+';

            }
        }
        static void RandomPassword()
        {
            
            Console.WriteLine("Please insert a password length: ");
            string input = Console.ReadLine();
            int length = numChecker(input);
            string password;
            while (length < 1 || length > 48) 
            {
                Console.WriteLine("This number is too big for a password please choose another one: ");
                input = Console.ReadLine();
                length = numChecker(input);
            }
            Console.Clear();   
            password = PasswordGenerator.PasswordGeneratorFun(length);
            Console.WriteLine(password);
            Console.WriteLine("Would you like to generate a new password Y/N?");
            string input2 = Console.ReadLine();
            char answer = charChecker(input2);
            while (answer != 'Y' && answer != 'y' && answer != 'N' && answer != 'n')
            {
                Console.WriteLine("Enter a valid option");
                input2 = Console.ReadLine();
                answer = charChecker(input2);
            }
            while (answer == 'Y' || answer == 'y')
            {
                Console.Clear();
                password = PasswordGenerator.PasswordGeneratorFun(length);
                Console.WriteLine(password);
                Console.WriteLine("Would you like to generate a new password Y/N?");
                input2 = Console.ReadLine();
                answer = charChecker(input2);
                while (answer != 'Y' && answer != 'y' && answer != 'N' && answer != 'n')
                {
                    Console.WriteLine("Enter a valid option");
                    input2 = Console.ReadLine();
                    answer = charChecker(input2);
                }
            }
            Console.Clear();   
            backMainMenu();
            
        }
        static void wordToPassword()
        {
            Console.WriteLine("Please enter a password you would like to improve(suggested password length: more than 10 characters)");
            string word = Console.ReadLine();
            while (word == null || word.Length < 3 || word.Length > 48) 
            {
                Console.WriteLine("Please enter a valid or longer word");
                word = Console.ReadLine();
            }
            Console.Clear();

            int maxLength = word.Length * 2;
            if (maxLength > 48)
            {
                maxLength = 48;
            }
            string newPass = mayusRandomizer(word);
            newPass = vowelToNumber(newPass);
            Console.WriteLine(newPass);
            Console.WriteLine("Would you like to generate a new password Y/N?");
            string input = Console.ReadLine();
            char answer = charChecker(input);
            while (answer != 'Y' && answer != 'y' && answer != 'N' && answer != 'n')
            {
                Console.WriteLine("Enter a valid option");
                input = Console.ReadLine();
                answer = charChecker(input);
            }
            while (answer == 'Y' || answer == 'y')
            {
                Console.Clear();
                newPass = mayusRandomizer(word);
                newPass = vowelToNumber(newPass);
                Console.WriteLine(newPass);
                Console.WriteLine("Would you like to generate a new password Y/N?");
                input = Console.ReadLine();
                answer = charChecker(input);
                while (answer != 'Y' && answer != 'y' && answer != 'N' && answer != 'n')
                {
                    Console.WriteLine("Enter a valid option");
                    input = Console.ReadLine();
                    answer = charChecker(input);
                }
            }
            Console.Clear();
            backMainMenu();
        }
        static string mayusRandomizer(string word)
        {
            Random random = new Random();
            StringBuilder sb = new StringBuilder(word);
            for(int i =  0; i < word.Length;i++) 
            {
                int tempRan = random.Next(2);
                int tempRan2 = random.Next(2);
                if (Char.IsLetter(word[i]) && Char.IsLower(word[i]) && tempRan == 1)
                {
                    sb[i] = char.ToUpper(word[i]);
                }
                else if (Char.IsLetter(word[i]) && Char.IsUpper(word[i]) && tempRan2 == 1)
                {
                    sb[i] = char.ToLower(word[i]);
                }
                else
                {
                    sb[i] = word[i];
                }
            }
            return(sb.ToString());
        }
        static string vowelToNumber (string word)
        {
            Random random = new Random();
            StringBuilder sb = new StringBuilder(word);
            for (int i = 0; i < word.Length; i++)
            {
                int tempRan = random.Next(2);
                if (isVowel(word[i]) && tempRan == 1)
                {
                    sb[i] = vowelToNumber(word[i]);
                }
                else
                {
                    sb[i] = word[i];
                }
            }
            return (sb.ToString());
        }
    }
}