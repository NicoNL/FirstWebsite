﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordGenerator
{
    public class PasswordGenerator
    {
        const string passContent = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789*#!@$%&()";

        public static string PasswordGeneratorFun(int length)
        {
            Random random = new Random();
            StringBuilder stringBuilder = new StringBuilder();
            int first = random.Next(passContent.Length);
            char firstChar = passContent[first];
            stringBuilder.Append(firstChar);
            for (int i = 1; i < length; i++)
            {
                int index = random.Next(passContent.Length);
                char randomChar = passContent[index];
                if (isVowel(stringBuilder[i - 1]))
                {
                    while (isVowel(randomChar))
                    {
                        index = random.Next(passContent.Length);
                        randomChar = passContent[index];
                    }
                }
                else
                {
                    while (!isVowel(randomChar))
                    {
                        index = random.Next(passContent.Length);
                        randomChar = passContent[index];
                    }
                }
                stringBuilder.Append(randomChar);
            }

            Console.WriteLine("New password generated:");
            return stringBuilder.ToString();
        }
        static bool isVowel(char ch)
        {
            if (char.IsUpper(ch))
            {
                ch = char.ToLower(ch);

            }
            if (ch == 'a' || ch == 'e' || ch == 'o' || ch == 'i' || ch == 'u')
            {
                return true;
            }
            return false;
        }
    }
}
